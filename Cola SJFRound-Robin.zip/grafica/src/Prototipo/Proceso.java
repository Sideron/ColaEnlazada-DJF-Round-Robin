package prototipo;

/**
 *
 * @author JUAN
 */
public class Proceso {
    private int tiempo;
    private int llegada;
    private String nombre;
    private Proceso siguiente;
    private int tComienzo;
    private int tFinal;
    public Proceso(String nombre,int tiempo, int llegada){
        this.llegada = llegada;
        this.tiempo = tiempo;
        this.nombre= nombre;
    }
    public void ejecutar(){
        tiempo--;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public void setTiempo(int t){
        tiempo = t;
    }
    public int getTiempo(){
        return tiempo;
    }
    public int getLlegada(){
        return llegada;
    }
    public void setLlegada(int llegada){
        this.llegada = llegada;
    }
    public void setSiguiente(Proceso siguiente){
        this.siguiente = siguiente;
    }
    public Proceso getSiguiente(){
        return siguiente;
    }
    public void setComienzo(int comienzo){
        tComienzo = comienzo;
    }
    public void setFinal(int fin){
        tFinal = fin;
    }
    public int getComienzo(){return tComienzo;}
    public int getFinal(){return tFinal;}
}