/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototipo;

/**
 *
 * @author JUAN
 */
public class CrearLista {
    private Proceso L;
    public CrearLista(){
    this.L=null;
}
    public void Insertar(String nombre,int tiempo,int llegada){
    Proceso proceso= new Proceso(nombre,tiempo,llegada);
    proceso.setSiguiente(null);
    if(L==null){
        
        L=proceso;
    }
    else{
        Proceso ptr= L;
        while(ptr.getSiguiente()!= null){
            ptr=ptr.getSiguiente();
        }
        
       ptr.setSiguiente(proceso);
    }
    }
    public void InsertarInicio(String nombre,int tiempo,int llegada){
        Proceso proceso= new Proceso(nombre,tiempo,llegada);
    proceso.setSiguiente(null);
        L=proceso;
    }
  
    public int Eliminar(int menor,int reloj, String priproceso){
        if(L.getTiempo()==menor){
            if(L.getNombre()!= priproceso){
            L.setComienzo(reloj);
            System.out.println("Tiempo "+ reloj+": El proceso "+L.getNombre()+" entra a ejecución");
            }
            reloj= reloj + L.getTiempo();
            L.setFinal(reloj);
            System.out.println("Tiempo "+ reloj+": El proceso "+L.getNombre()+" termina su ejecución");

            L=L.getSiguiente();
        }
        else{
            Proceso ptr= L.getSiguiente();
            Proceso aux= L;
            while(ptr!=null&& ptr.getTiempo()!=menor){
                aux=ptr;
                ptr=ptr.getSiguiente();
            }
            ptr.setComienzo(reloj);
            System.out.println("Tiempo "+ reloj+": El proceso"+ptr.getNombre()+" entra a ejecución");
            reloj= reloj + ptr.getTiempo();
            ptr.setFinal(reloj);
            System.out.println("Tiempo "+ reloj+": El proceso"+ptr.getNombre()+" termina su ejecución");

            aux.setSiguiente(ptr.getSiguiente());
        }
        return reloj;}
    
    
    public int Procesomenor(){
        int menor= 9000;
       Proceso ptr= L;
       while(ptr!=null){
           if(ptr.getTiempo()<=menor){
               menor=ptr.getTiempo();
           }
           ptr=ptr.getSiguiente();
       }
      
       return menor;
    } 
    
    public void QuantumEsMayor(){
        int tiempo=L.getTiempo();
        int llegada=L.getLlegada();
        String nombre= L.getNombre();
        Insertar(nombre,tiempo,llegada);
        L=L.getSiguiente();
    }
    
    public void RoundRobin(){
        int reloj=L.getLlegada();
        Proceso ptr=L.getSiguiente();
        while(L!=null){
            L.setComienzo(reloj);
            System.out.println("Tiempo "+ reloj+": El proceso "+L.getNombre()+" empieza su ejecucion");
            while(ptr!=null&&ptr.getLlegada()<L.getTiempo()+reloj){
                System.out.println("Tiempo "+ ptr.getLlegada()+": Llega el proceso "+ptr.getNombre());
                ptr=ptr.getSiguiente();
            }

            if(L.getTiempo()-20>0){
                reloj=reloj+20;
                L.setTiempo(L.getTiempo()-20);
                System.out.println("Tiempo "+ reloj+": El proceso "+L.getNombre()+" se conmuta. Pendiente por ejecutar: "+L.getTiempo()+"ms");
                QuantumEsMayor();
            }
            else{
                reloj=reloj+L.getTiempo();
                L.setFinal(reloj);
                System.out.println("Tiempo "+ reloj+": El proceso "+L.getNombre()+" termina su ejecución");

                L=L.getSiguiente();
            }
        }
    }
    
  public void SJF(){
      String priproceso= L.getNombre();
      int reloj=L.getLlegada();
      //Tiempo de reloj= 1er proceso empieza su ejecucion
      Proceso ptr=L.getSiguiente();
      System.out.println("Tiempo "+ reloj+": El proceso "+L.getNombre()+" entra a ejecución");
      while(ptr!=null&&ptr.getLlegada()<L.getTiempo()+reloj){
                System.out.println("Tiempo "+ ptr.getLlegada()+": Llega el proceso "+ptr.getNombre());         
                ptr=ptr.getSiguiente();
            }
      reloj=Eliminar(L.getTiempo(),reloj,priproceso);
      
      //Tiempo de reloj es cuando el proceso 1 termina;
      while(L!=null){
          while(ptr!=null&&ptr.getLlegada()<L.getTiempo()+reloj){
                System.out.println("Tiempo "+ ptr.getLlegada()+": Llega el proceso "+ptr.getNombre());
                ptr=ptr.getSiguiente();
            }
          int menor= Procesomenor();
          //Tiempo de reloj= proceso x empieza su ejecucion
          reloj=Eliminar(menor,reloj,priproceso);
          //Tiempo de reloj= proceso x termina su ejecucion 
      }
      System.out.println("Tiempo "+reloj+": Se ejecutaron todos los procesos");
  }
  public void ordenarTiempo(){
        Proceso temp = null;
        while(L!=null){
            Proceso pt = L;
            Proceso pTemp = temp;
            Proceso choosed = null;
            Proceso preChoosed = null;
            Proceso prePt = null;
            int n = 1000;
            while(pt!=null){
                
                Proceso ptt = pt;
                pt = pt.getSiguiente();
                if(ptt.getLlegada()<n){
                    n = ptt.getLlegada();
                    preChoosed = prePt;
                    choosed = ptt;
                }
                prePt = ptt;
            }
            if(preChoosed!=null)
                preChoosed.setSiguiente(choosed.getSiguiente());
            else if(choosed.getSiguiente()!=null)
                L = choosed.getSiguiente();
            else
                L = null;
            choosed.setSiguiente(null);
            while(pTemp!=null && pTemp.getSiguiente()!=null){
                //if(pTemp.getSiguiente()!=null){
                
                pTemp = pTemp.getSiguiente();
            }
            if(pTemp!=null)
                pTemp.setSiguiente(choosed);
            else
                pTemp = choosed;
            if(temp==null)
                temp = pTemp;
        }
        L = temp;
    }
  
  
    public void mostrar(){
       Proceso pt = L;
        while(pt!=null){
            System.out.print(pt.getTiempo()+"|"+pt.getLlegada()+"|"+pt.getNombre()+"\n");
            pt = pt.getSiguiente();
    }
}
   public Object[] obtenerdato(int pos){
    Object[] data = new Object[5];
    Proceso pt = L;
    for(int i=0;i<pos;i++){
            if(pt.getSiguiente()!=null)
        pt = pt.getSiguiente();
            else
        pt = null;
    }
        if(pt!=null){
        data[0] = pt.getNombre();
        data[1] = pt.getTiempo();
        data[2] = pt.getLlegada();
        data[3] = pt.getComienzo();
        data[4] = pt.getFinal();
        return data;
        }else{return null;}
    }
}
