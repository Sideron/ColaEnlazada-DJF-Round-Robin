package prototipo;

/**
 *
 * @author JUAN
 */
public class main {
    public static void main(String[] args) {
        CrearLista lista1= new CrearLista();
        lista1.Insertar("Proceso 5",6, 5);
        lista1.Insertar("Proceso 4",9, 4);
        lista1.Insertar("Proceso 3",30, 3);
        lista1.Insertar("Proceso 2",50, 2);
        lista1.Insertar("Proceso 1",20, 1);
        lista1.ordenarTiempo();
        lista1.mostrar();
        //lista1.SJB();
        lista1.RoundRobin();
        System.out.println("---------");
        lista1.mostrar();
        /*for(int i=0;i<10;i++){
            cola1.ejecutar();
        }
        /Proceso pr = cola1.getRoot();
        for(int i=0;i<2;i++){
            pr = pr.getSiguiente();
        }*/
        //cola1.seleccionarSJF();

    }
    
}